<?php
// include your composer dependencies
require_once 'vendor/autoload.php';

$clientId = '5555555555555555555555555555555555555555555555.apps.googleusercontent.com';
$clientSecret = 'PPPPPPPPPPPPPPPPPPPPPPPP';
$redirect_uri = 'http://localhost/satheesh/googleLogin/';
//$redirect_uri = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];

$client = new Google_Client();

//$client->useApplicationDefaultCredentials();
//$client->addScope(Google_Service_Plus::PLUS_ME);
//
//// returns a Guzzle HTTP Client
//$httpClient = $client->authorize();
//
//// make an HTTP request
////$response = $httpClient->get('https://www.googleapis.com/plus/v1/people/me');
////echo '<pre>';
////print_r($response);
////echo '</pre>';
//die;

$client->setAuthConfig('client_credentials.json');
//$client->addScope(Google_Service_Drive::DRIVE);
$client->setScopes('profile email');
//$client->setScopes('email');
$client->setRedirectUri($redirect_uri);

if (isset($_REQUEST['logout'])) {
  unset($_SESSION['id_token_token']);
}
if (isset($_GET['code'])) {
  $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);

  // store in the session also
  $_SESSION['id_token_token'] = $token;

  // redirect back to the example
  header('Location: ' . filter_var($redirect_uri, FILTER_SANITIZE_URL));
  return;
}

if (
  !empty($_SESSION['id_token_token'])
  && isset($_SESSION['id_token_token']['id_token'])
) {
  $client->setAccessToken($_SESSION['id_token_token']);
} else {
  $authUrl = $client->createAuthUrl();
}

if ($client->getAccessToken()) {
  $token_data = $client->verifyIdToken();
}


//if (isset($_GET['code'])) {
//    $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);
//}
//echo '<pre>';
//print_r($token);
//echo '</pre>';

//$client->setApplicationName("Client_Library_Examples");
//$client->setDeveloperKey("AIzaSyCg4hWW1t3PSudsLVrEM5qUZOmDYluNvQQ");
//$service = new Google_Service_Books($client);

//echo '<pre>';
//print_r($service);
//echo '</pre>';

//$optParams = array('filter' => 'free-ebooks');
//echo '<pre>';
//print_r($optParams);
//echo '</pre>';

//$results = $service->volumes->listVolumes('Henry David Thoreau', $optParams);
//
//foreach ($results->getItems() as $item) {
//  echo $item['volumeInfo']['title'], "<br /> \n";
//}


//$client->setClientId($clientId);
//$client->setClientSecret($clientSecret);
//$client->setRedirectUri($redirectUrl);
//if (isset($_GET['code'])) {
//    $client->authenticate($_GET['code']);
//    $token = $client->getAccessToken();
//}
//print '<a href="' . $client->createAuthUrl() . '">Authenticate</a>';
?>
<div class="box">
<?php if (isset($authUrl)): ?>
  <div class="request">
    <a class='login' href='<?= $authUrl ?>'>Connect Me!</a>
  </div>
<?php else: ?>
  <div class="data">
    <p>Here is the data from your Id Token:</p>
    <pre><?php var_export($token_data) ?></pre>
  </div>
<?php endif ?>
</div>